# Lab 1
Hello and welcome to Lab 1 in CSC 412. :)

Our goal is to help you set-up and get started with the course's development environment.

