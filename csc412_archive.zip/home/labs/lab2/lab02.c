#include <stdio.h>

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Usage: %s <integer1> <integer2> ... <integerN>\n", argv[0]);
        return 1;
    }

    for (int i = 1; i < argc; i++) {
        int num;
        if (sscanf(argv[i], "%d", &num) == 1) {
            printf("%d\n", num);
        }
    }

    return 0;
}
