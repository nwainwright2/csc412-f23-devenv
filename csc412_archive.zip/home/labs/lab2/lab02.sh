#!/bin/bash

# Check for the correct number of arguments
if [ "$#" -lt 2 ]; then
    echo "Usage: $0 <C_source_file> <integer1> [integer2] [integer3] [...]"
    exit 1
fi

# Extract the C source file name and remove the file extension
source_file="$1"
program_name="${source_file%.*}"

# Compile the C program and capture the output
gcc -Wall "$source_file" -o "$program_name"
gcc_output=$(gcc -Wall "$source_file" -o "$program_name" 2>&1)

# Check if compilation was successful
if [ "$?" -ne 0 ]; then
    echo "Compilation failed: $gcc_output"
    exit 2
fi


# Shift to skip the first argument (C source file) and execute the program
shift
./"$program_name" "$@"
